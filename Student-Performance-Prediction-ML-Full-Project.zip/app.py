import os
import sys
import joblib
import pandas as pd
import streamlit as st

sys.path.append("src")
from data_preprocessing import prepare_data

DATA_PATH = "dataset/StudentsPerformance.csv"
MODEL_PATH = "models/student_performance_model.pkl"

st.set_page_config(page_title="Student Performance Analyzer", layout="wide")
st.title("Student Performance Prediction and Analysis")
st.caption("Machine Learning project based on the StudentsPerformance dataset.")

@st.cache_data
def get_data():
    return prepare_data(pd.read_csv(DATA_PATH))

@st.cache_resource
def get_model():
    if not os.path.exists(MODEL_PATH):
        st.error("Trained model not found. Run: python src/model_training.py")
        st.stop()
    return joblib.load(MODEL_PATH)

df = get_data()
model = get_model()

c1,c2,c3,c4 = st.columns(4)
c1.metric("Total Students", len(df))
c2.metric("Avg Math", f"{df.math_score.mean():.1f}")
c3.metric("Avg Reading", f"{df.reading_score.mean():.1f}")
c4.metric("Avg Writing", f"{df.writing_score.mean():.1f}")

st.subheader("Dataset Preview")
st.dataframe(df.head(20), use_container_width=True)

st.subheader("Performance Distribution")
st.bar_chart(df["performance_category"].value_counts().sort_index())

st.subheader("Student Performance Prediction")
col1,col2,col3 = st.columns(3)
with col1:
    gender = st.selectbox("Gender", sorted(df["gender"].unique()))
    race = st.selectbox("Race/Ethnicity", sorted(df["race_ethnicity"].unique()))
with col2:
    education = st.selectbox("Parental Education", sorted(df["parental_education"].unique()))
    lunch = st.selectbox("Lunch", sorted(df["lunch"].unique()))
with col3:
    preparation = st.selectbox("Test Preparation", sorted(df["test_preparation"].unique()))

if st.button("Predict Performance"):
    sample = pd.DataFrame([{
        "gender": gender,
        "race_ethnicity": race,
        "parental_education": education,
        "lunch": lunch,
        "test_preparation": preparation,
    }])
    result = model.predict(sample)[0]
    st.success(f"Predicted Performance Category: {result}")

st.subheader("Subject-wise Statistics")
st.dataframe(
    df[["math_score","reading_score","writing_score"]].describe().round(2),
    use_container_width=True
)
